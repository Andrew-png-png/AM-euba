package sk.mrna.todolist.repository;

import org.springframework.data.repository.CrudRepository;
import sk.mrna.todolist.dao.User;

import java.util.List;

public interface UserRepository extends CrudRepository<User, Long> {
    boolean existsByUsername(String username);

    List<User> findByUsername(String username);
}
