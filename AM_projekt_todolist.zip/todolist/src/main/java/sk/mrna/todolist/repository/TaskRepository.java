package sk.mrna.todolist.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;
import sk.mrna.todolist.dao.Task;
import sk.mrna.todolist.dao.User;

import java.util.List;

public interface TaskRepository extends CrudRepository<Task, Long> {
    List<Task> findByUserAndDoneFalse(User user);
    @Transactional
    @Modifying
    @Query("update todo_list_task t set t.done = ?1 where t.id = ?2")
    int updateDoneById(boolean done, Long id);

}
