package sk.mrna.todolist.dto;

import sk.mrna.todolist.dao.Task;
import sk.mrna.todolist.dao.User;

public class CreateTaskDto {
    private String username;
    private String password;
    private String description;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getDescription() {
        return description;
    }
}
