package sk.mrna.todolist.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sk.mrna.todolist.dao.Task;
import sk.mrna.todolist.dao.User;
import sk.mrna.todolist.dto.CreateTaskDto;
import sk.mrna.todolist.dto.DeleteTaskDto;
import sk.mrna.todolist.dto.ResolveTaskDto;
import sk.mrna.todolist.repository.TaskRepository;
import sk.mrna.todolist.repository.UserRepository;

import java.util.List;
import java.util.Optional;

@RestController
public class TasksController {
    @Autowired
    UserRepository userRepository;
    @Autowired
    private TaskRepository taskRepository;

    @PostMapping("/task")
    public Task createTask(@RequestBody CreateTaskDto createTaskDto) {
        if (!userRepository.existsByUsername(createTaskDto.getUsername())) {
            throw new RuntimeException("Username not found");
        }

        User givenUser = userRepository.findByUsername(createTaskDto.getUsername()).get(0);

        if (createTaskDto.getPassword().equals(givenUser.getPassword())) {
            Task newTask = new Task(createTaskDto.getDescription());
            newTask.setUser(givenUser);

            return taskRepository.save(newTask);
        } else {
            throw new RuntimeException("User not verified");
        }
    }

    @GetMapping("/unresolved-tasks")
    public List<Task> getUnresolvedTasks(@RequestBody User user) {
        if (!userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username not found");
        }

        User givenUser = userRepository.findByUsername(user.getUsername()).get(0);

        if (user.getPassword().equals(givenUser.getPassword())) {
            return taskRepository.findByUserAndDoneFalse(givenUser);
        } else {
            throw new RuntimeException("User not verified");
        }
    }


    @PostMapping("/resolve-task")
    public void resolveTask(@RequestBody ResolveTaskDto resolveTaskDto) {
        if (!userRepository.existsByUsername(resolveTaskDto.getUsername())) {
            throw new RuntimeException("Username not found");
        }

        List<User> usersByUsername = userRepository.findByUsername(resolveTaskDto.getUsername());

        if (resolveTaskDto.getPassword().equals(usersByUsername.get(0).getPassword())) {
            taskRepository.updateDoneById(true, resolveTaskDto.getTaskId());
        } else {
            throw new RuntimeException("User not verified");
        }
    }

    @DeleteMapping("/task")
    public void deleteTask(@RequestBody DeleteTaskDto deleteTaskDto) {
        if (!userRepository.existsByUsername(deleteTaskDto.getUsername())) {
            throw new RuntimeException("Username not found");
        }

        User givenUser = userRepository.findByUsername(deleteTaskDto.getUsername()).get(0);

        if (deleteTaskDto.getPassword().equals(givenUser.getPassword())) {
            Optional<Task> taskToBeDeleted = taskRepository.findById(deleteTaskDto.getTaskId());

            if (taskToBeDeleted.isEmpty()) {
                throw new RuntimeException("Task does not exists");
            } else if (taskToBeDeleted.get().getUser().getUsername().equals(givenUser.getUsername())) {
                taskRepository.deleteById(deleteTaskDto.getTaskId());
            } else {
                throw new RuntimeException("Task is not owned by given user");
            }
        } else {
            throw new RuntimeException("User not verified");
        }
    }
}
