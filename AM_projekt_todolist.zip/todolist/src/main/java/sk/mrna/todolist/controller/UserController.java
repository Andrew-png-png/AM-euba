package sk.mrna.todolist.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import sk.mrna.todolist.dao.User;
import sk.mrna.todolist.repository.UserRepository;

import java.util.List;

@RestController
public class UserController {
    @Autowired
    UserRepository userRepository;

    @PostMapping("/user")
    public Long createUser(@RequestBody User user) {
        return userRepository.save(user).getId();
    }

    @DeleteMapping("/user")
    public void deleteUser(@RequestBody User user) {
        if (!userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username not found");
        }

        List<User> usersByUsername = userRepository.findByUsername(user.getUsername());;

        if (user.getPassword().equals(usersByUsername.get(0).getPassword())) {
            userRepository.delete(usersByUsername.get(0));
        } else {
            throw new RuntimeException("User not verified");
        }
    }
}
