package sk.mrna.todolist.dto;

import sk.mrna.todolist.dao.User;

public class ResolveTaskDto {
    private String username;
    private String password;
    private Long taskId;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public Long getTaskId() {
        return taskId;
    }
}
